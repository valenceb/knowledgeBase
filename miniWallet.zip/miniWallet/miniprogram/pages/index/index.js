//index.js
const app = getApp()

Page({
  data: {
    depositNum : 0,
    btnLoading : false,
    expense : '',
    avatarUrl: './user-unlogin.png',
    userInfo: {},
    hasUserInfo: false,
    logged: false,
    takeSession: false,
    requestResult: '',
    canIUseGetUserProfile: false,
    canIUseOpenData: wx.canIUse('open-data.type.userAvatarUrl') // 如需尝试获取用户信息可改为false
  },

  onLoad: function() {
    wx.request({
      url: 'https://api.vika.cn/fusion/v1/datasheets/dst0So8SGoFQNWtzR5/records?viewId=viwSH69wPWsVi&fieldKey=name', 
      header:{
        'Authorization': 'Bearer uskdr52BARtfohtDzCoGGUn',
      },
      success: res => {
        console.log(res.data);
        let resVika = res.data.data;
        if(resVika && resVika.pageSize > 0){
          console.log(resVika.records[resVika.pageSize-1].fields.deposit);
          // this.data.depositNum = resVika.records[0].fields.deposit
          this.setData({
            depositNum: resVika.records[resVika.pageSize-1].fields.deposit
          })
        }
      }
    })
  },
  spendMoney: function() {
    if(!this.data.btnLoading){
      let pocket0 = this.data.depositNum;
      pocket0 = pocket0 - this.data.expense;
      this.setData({
        btnLoading : true,
      });
      wx.request({
        url: 'https://api.vika.cn/fusion/v1/datasheets/dst0So8SGoFQNWtzR5/records?viewId=viwSH69wPWsVi&fieldKey=name', 
        header:{
          'Authorization': 'Bearer uskdr52BARtfohtDzCoGGUn',
          'Content-Type': 'application/json'
        },
        method: 'POST',
        data:{
          "records": [
          {
            "fields": {
              "deposit": pocket0,
              "date": new Date()
            }
          }
        ],
          "fieldKey": "name"
        },
        success: res => {
          console.log(res.data);
          console.log(this.data.depositNum);
          console.log(this.data.expense);
          let pocket = this.data.depositNum;
          pocket = pocket - this.data.expense;
          this.setData({
            btnLoading : false,
            depositNum : pocket,
            expense : ''
          })
        },
        fail: res => {
          console.log(res.data);
          this.showToast(res.data.message);
          this.setData({
            btnLoading : false,
          })
        }
      })
    }
  },
  bindKeyInput: function (e) {
    this.setData({
      expense: e.detail.value
    })
  },
  getUserProfile() {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        this.setData({
          avatarUrl: res.userInfo.avatarUrl,
          userInfo: res.userInfo,
          hasUserInfo: true,
        })
      }
    })
  },

  onGetUserInfo: function(e) {
    if (!this.data.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo,
        hasUserInfo: true,
      })
    }
  },

  onGetOpenid: function() {
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
        wx.navigateTo({
          url: '../userConsole/userConsole',
        })
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  // 上传图片
  doUpload: function () {
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        wx.showLoading({
          title: '上传中',
        })

        const filePath = res.tempFilePaths[0]
        
        // 上传图片
        const cloudPath = `my-image${filePath.match(/\.[^.]+?$/)[0]}`
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)

            app.globalData.fileID = res.fileID
            app.globalData.cloudPath = cloudPath
            app.globalData.imagePath = filePath
            
            wx.navigateTo({
              url: '../storageConsole/storageConsole'
            })
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading()
          }
        })
      },
      fail: e => {
        console.error(e)
      }
    })
  },

})
